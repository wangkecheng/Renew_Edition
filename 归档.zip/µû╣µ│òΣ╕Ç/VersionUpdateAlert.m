//
//  VersionUpdateAlert.m
//  luban-ios
//
//  Created by warron on 16/9/18.
//  Copyright © 2016年 wghx. All rights reserved.
//

#import "VersionUpdateAlert.h"

@implementation VersionUpdateAlert


+ (instancetype)shareVersionUpdateAlert
{
    static VersionUpdateAlert *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[VersionUpdateAlert alloc] init];
    });
    return instance;
}

- (void)checkAndShowWithAppID:(NSString *)appID andController:(UIViewController *)VC
{
    NSString *urlString = [NSString stringWithFormat:@"http://itunes.apple.com/cn/lookup?id=%@",appID];
    [[NetworkTools shareNetworkTools] requestWithMethod:get andUrlString:urlString andParameters:nil andFinished:^(id response, NSError *error) {
        if (error == nil) {
            NSArray *array = response[@"results"];
            NSDictionary *dict = [array lastObject];
            NSLog(@"当前版本为：%@", dict[@"version"]);
            // 获取info的字典
            NSDictionary* infoDict = [NSBundle mainBundle].infoDictionary;
            // 版本号保存在本地
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString* appVersion = infoDict[@"CFBundleShortVersionString"];
            NSString *versionString = [userDefaults objectForKey:@"versionString"];
            if (versionString == nil) {
                [userDefaults setObject:appVersion forKey:@"versionString"];
            }
            //当版本更新后重置interCount
            if (![[userDefaults objectForKey:@"versionString"] isEqualToString:appVersion]) {
                [userDefaults setObject:@"0" forKey:@"interCount"];
                [userDefaults setObject:appVersion forKey:@"versionString"];
            }
            if ([dict[@"version"] compare:appVersion] == NSOrderedDescending) {
                
                NSNumber *interCount = [userDefaults objectForKey:@"interCount"];
                if (interCount == nil) {
                    [self alertShowWithAppID:appID andController:VC];
                }
                if ([interCount integerValue]%(self.interCount ? self.interCount : 20) == 0) {
                    [self alertShowWithAppID:appID andController:VC];
                }
                NSInteger integerInterCount = [interCount integerValue];
                integerInterCount++;
                NSNumber *numberInterCount = [NSNumber numberWithInteger:integerInterCount];
                [userDefaults setObject:numberInterCount forKey:@"interCount"];
            }
        }
    }];
}

//弹出的alertView
- (void)alertShowWithAppID:(NSString *)appID andController:(UIViewController *)VC
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"版本更新提醒" message:@"鲁班联盟新版本更新，快来更新吧" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *installAction = [UIAlertAction actionWithTitle:@"安装" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self openAppaleShopWithAppID:appID];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:installAction];
    [alertController addAction:cancelAction];
    [VC presentViewController:alertController animated:YES completion:nil];
}

//打开appStore
- (void)openAppaleShopWithAppID:(NSString *)appID
{
    NSString *str = [NSString stringWithFormat:@"itms-apps://itunes.apple.com/app/id%@",appID];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}

@end
